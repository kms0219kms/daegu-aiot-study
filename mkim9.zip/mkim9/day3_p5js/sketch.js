function setup() {
  const pis = [QUARTER_PI, HALF_PI, PI, PI + HALF_PI, TWO_PI]
  let i = 0;

  createCanvas(400, 400);
  arc(200, 200, 300, 300, 0, pis[0]);
  i++

  setInterval(() => {
    createCanvas(400, 400);
    arc(200, 200, 300, 300, 0, pis[i]);

    if (i + 1 >= pis.length) {
      i = 0;
    } else {
      i++;
    }
  }, 1000)
}
